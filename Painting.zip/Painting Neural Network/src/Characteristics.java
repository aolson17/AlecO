public class Characteristics {
	
	int speedAmount = 1;
	int speedLength = 5;
	
	
	
	
	public int[] determineLineAmount(int lineAmount, int prevLineAmount){
		
		int tempPrevLineValue = prevLineAmount;
		prevLineAmount = lineAmount;
		
		if (lineAmount-tempPrevLineValue > 0){
			lineAmount += speedAmount;
		}else if (lineAmount-tempPrevLineValue < 0){
			lineAmount -= speedAmount;
		}else{
			if (Math.random() >= .5){
				lineAmount += speedAmount;
			}else{
				lineAmount -= speedAmount;
			}
		}
		
		if (lineAmount <= 0){lineAmount = 1;}
		
		int[] output = new int[2];
		output[0] = lineAmount;
		output[1] = prevLineAmount;
		
		return output;
	}
	
	public int[] determineLineLength(int lineLength, int prevLineLength){
		
		int tempPrevLineValue = prevLineLength;
		prevLineLength = lineLength;
		
		if (lineLength-tempPrevLineValue > 0){
			lineLength += speedLength;.
			
		}else if (lineLength-tempPrevLineValue < 0){
			lineLength -= speedLength;
		}else{
			if (Math.random() >= .5){
				lineLength += speedLength;
			}else{
				lineLength -= speedLength;
			}
		}
		
		if (lineLength <= 20){lineLength = 20;}
		
		int[] output = new int[2];
		output[0] = lineLength;
		output[1] = prevLineLength;
		
		return output;
	}
	
	public float[] determineLineVerticality(float lineVerticality, float prevLineVerticality){
		
		float tempPrevLineValue = prevLineVerticality;
		prevLineVerticality = lineVerticality;
		
		if (lineVerticality-tempPrevLineValue > 0){
			lineVerticality += speedLength;
		}else if (lineVerticality-tempPrevLineValue < 0){
			lineVerticality -= speedLength;
		}else{
			if (Math.random() >= .5){
				lineVerticality += speedLength;
			}else{
				lineVerticality -= speedLength;
			}
		}
		
		if (lineVerticality <= 20){lineVerticality = 20;}
		
		int[] output = new int[2];
		output[0] = lineVerticality;
		output[1] = prevLineVerticality;
		
		return output;
	}

	public float determineLineVerticality(float lineVerticality){
		if (Math.random() > .5){
			lineVerticality += Math.abs(Math.random()-Math.random())*lineVerticality;
		}else{
			lineVerticality -= Math.abs(Math.random()-Math.random())*lineVerticality;
		}
		if (lineVerticality <= 0){lineVerticality = (float) .05;}
		if (lineVerticality > 1){lineVerticality = 1;}
		return lineVerticality;
	}

	public float determineLineOpacity(float lineOpacity){
		if (Math.random() > .5){
			lineOpacity += Math.abs(Math.random()-Math.random())*lineOpacity;
		}else{
			lineOpacity -= Math.abs(Math.random()-Math.random())*lineOpacity;
		}
		if (lineOpacity <= 0){lineOpacity = (float) .1;}
		if (lineOpacity > 1){lineOpacity = 1;}
		return lineOpacity;
	}
	
	
	
	public float determineLineConcentrationX(float lineConcentrationX){
		if (Math.random() > .5){
			lineConcentrationX += Math.abs(Math.random()-Math.random())*lineConcentrationX;
		}else{
			lineConcentrationX -= Math.abs(Math.random()-Math.random())*lineConcentrationX;
		}
		if (lineConcentrationX <= 0){lineConcentrationX = (float) .05;}
		if (lineConcentrationX > 1){lineConcentrationX = 1;}
		return lineConcentrationX;
	}
	
	public float determineLineConcentrationY(float lineConcentrationY){
		if (Math.random() > .5){
			lineConcentrationY += Math.abs(Math.random()-Math.random())*lineConcentrationY;
		}else{
			lineConcentrationY -= Math.abs(Math.random()-Math.random())*lineConcentrationY;
		}
		if (lineConcentrationY <= 0){lineConcentrationY = (float) .05;}
		if (lineConcentrationY > 1){lineConcentrationY = 1;}
		return lineConcentrationY;
	}
	
	// number of lines
	// -lineAmount
	// verticality of lines
	// -lineVerticality
	// length of lines
	// -lineLength
	// opacity of lines
	// -lineOpacity
	// line concentration
	// -lineConcentration
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
