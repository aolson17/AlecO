public class Characteristics {
	
	int speedAmount = 1;
	int speedLength = 5;
	float speedVerticality = (float) .1;
	float speedConcentration = (float) .1;
	float speedOpacity = (float) .1;
	
	
	
	public int[] determineLineAmount(int lineAmount, int prevLineAmount){
		
		int tempPrevLineValue = prevLineAmount;
		prevLineAmount = lineAmount;
		
		if (lineAmount-tempPrevLineValue > 0){
			lineAmount += speedAmount;
		}else if (lineAmount-tempPrevLineValue < 0){
			lineAmount -= speedAmount;
		}else{
			if (Math.random() >= .5){
				lineAmount += speedAmount;
			}else{
				lineAmount -= speedAmount;
			}
		}
		
		if (lineAmount <= 0){lineAmount = 1;}
		
		int[] output = new int[2];
		output[0] = lineAmount;
		output[1] = prevLineAmount;
		
		return output;
	}
	
	public int[] determineLineLength(int lineLength, int prevLineLength){
		
		int tempPrevLineValue = prevLineLength;
		prevLineLength = lineLength;
		
		if (lineLength-tempPrevLineValue > 0){
			lineLength += speedLength;
			
		}else if (lineLength-tempPrevLineValue < 0){
			lineLength -= speedLength;
		}else{
			if (Math.random() >= .5){
				lineLength += speedLength;
			}else{
				lineLength -= speedLength;
			}
		}
		
		if (lineLength <= 20){lineLength = 20;}
		
		int[] output = new int[2];
		output[0] = lineLength;
		output[1] = prevLineLength;
		
		return output;
	}
	
	public float[] determineLineVerticality(float lineVerticality, float prevLineVerticality){
		
		float tempPrevLineValue = prevLineVerticality;
		prevLineVerticality = lineVerticality;
		
		if (lineVerticality-tempPrevLineValue > 0){
			lineVerticality += speedVerticality;
		}else if (lineVerticality-tempPrevLineValue < 0){
			lineVerticality -= speedVerticality;
		}else{
			if (Math.random() >= .5){
				lineVerticality += speedVerticality;
			}else{
				lineVerticality -= speedVerticality;
			}
		}
		
		if (lineVerticality <= .2){lineVerticality = (float) .2;}
		if (lineVerticality >= 1){lineVerticality = 1;}
		
		float[] output = new float[2];
		output[0] = lineVerticality;
		output[1] = prevLineVerticality;
		
		return output;
	}
	
	public float[] determineLineConcentrationX(float lineConcentrationX, float prevLineConcentrationX){
		
		float tempPrevLineValue = prevLineConcentrationX;
		prevLineConcentrationX = lineConcentrationX;
		
		if (lineConcentrationX-tempPrevLineValue > 0){
			lineConcentrationX += speedConcentration;
		}else if (lineConcentrationX-tempPrevLineValue < 0){
			lineConcentrationX -= speedConcentration;
		}else{
			if (Math.random() >= .5){
				lineConcentrationX += speedConcentration;
			}else{
				lineConcentrationX -= speedConcentration;
			}
		}
		
		if (lineConcentrationX < 0){lineConcentrationX = 0;}
		if (lineConcentrationX > 1){lineConcentrationX = 1;}
		
		float[] output = new float[2];
		output[0] = lineConcentrationX;
		output[1] = prevLineConcentrationX;
		
		return output;
	}
	
	public float[] determineLineConcentrationY(float lineConcentrationY, float prevLineConcentrationY){
		
		float tempPrevLineValue = prevLineConcentrationY;
		prevLineConcentrationY = lineConcentrationY;
		
		if (lineConcentrationY-tempPrevLineValue > 0){
			lineConcentrationY += speedConcentration;
		}else if (lineConcentrationY-tempPrevLineValue < 0){
			lineConcentrationY -= speedConcentration;
		}else{
			if (Math.random() >= .5){
				lineConcentrationY += speedConcentration;
			}else{
				lineConcentrationY -= speedConcentration;
			}
		}
		
		if (lineConcentrationY < 0){lineConcentrationY = 0;}
		if (lineConcentrationY > 1){lineConcentrationY = 1;}
		
		float[] output = new float[2];
		output[0] = lineConcentrationY;
		output[1] = prevLineConcentrationY;
		
		return output;
	}
	
	public float[] determineLineOpacity(float lineOpacity, float prevLineOpacity){
		
		float tempPrevLineValue = prevLineOpacity;
		prevLineOpacity = lineOpacity;
		
		if (lineOpacity-tempPrevLineValue > 0){
			lineOpacity += speedOpacity;
		}else if (lineOpacity-tempPrevLineValue < 0){
			lineOpacity -= speedOpacity;
		}else{
			if (Math.random() >= .5){
				lineOpacity += speedOpacity;
			}else{
				lineOpacity -= speedOpacity;
			}
		}
		
		if (lineOpacity < .1){lineOpacity = (float) .1;}
		if (lineOpacity > 1){lineOpacity = 1;}
		
		float[] output = new float[2];
		output[0] = lineOpacity;
		output[1] = prevLineOpacity;
		
		return output;
	}
	
	
	
	
	
	
	// number of lines
	// -lineAmount
	// verticality of lines
	// -lineVerticality
	// length of lines
	// -lineLength
	// opacity of lines
	// -lineOpacity
	// line concentration
	// -lineConcentration
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
