import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;

import javax.imageio.ImageIO;
import javax.swing.*;

public class Main{
    
	float prevLineVerticality;
	
	float prevLineOpacity;
	float prevLineConcentrationY;
	float prevLineConcentrationX;
	
    int lineAmount = (int) Math.round(Math.random()*10);
    int prevLineAmount = lineAmount;
    
    int lineLength = 50;// average length of lines
    int prevLineLength = lineLength;
    
	float lineVerticality =  (float) Math.random();// percentage of lines that are vertical
	
	float lineOpacity = 1;
	float lineConcentrationY = (float) .2;// closeness of lines to each other from vertical axis in percentage
	float lineConcentrationX = (float) .2;// closeness of lines to each other from horizontal axis in percentage
    
    
    static Characteristics CA;
    static DrawArea DA; 
    
	JButton skipBtn, approveBtn, rejectBtn; 
    ActionListener actionListener = new ActionListener() {
    	
    	public void actionPerformed(ActionEvent e) {
        	if (e.getSource() == skipBtn){
        		DA.clear();
        	}else if (e.getSource() == approveBtn){
        		approve();	
        	}else if (e.getSource() == rejectBtn){
        		reject();	
        	}
    	}
    };
    
	static public void main(String args[]) throws Exception{
		DA = new DrawArea();
		CA = new Characteristics();
		new Main().show();
	}
	
	public void show() {
		JFrame frame = new JFrame("Paint");
		Container content = frame.getContentPane();
		content.setLayout(new BorderLayout());
		content.add(DA, BorderLayout.CENTER);
		JPanel controls = new JPanel();
		
		approveBtn = new JButton("Approve");
		approveBtn.addActionListener(actionListener);
		rejectBtn = new JButton("Reject");
		rejectBtn.addActionListener(actionListener);
		skipBtn = new JButton("Skip");
		skipBtn.addActionListener(actionListener);
		
		controls.add(approveBtn);
		controls.add(rejectBtn);
		controls.add(skipBtn);
		
		content.add(controls, BorderLayout.NORTH);
		
		frame.setSize(600, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
		
	}
	public void reject() {
		System.out.println("reject");
		
		int tempLineAmount = lineAmount;
		lineAmount = prevLineAmount;
		prevLineAmount = tempLineAmount;
		System.out.println("lineAmount: " + lineAmount);
		
		int tempLineLength = lineLength;
		lineLength = prevLineLength;
		prevLineLength = tempLineLength;
		System.out.println("lineLength: " + lineLength);
		
	}
	public void approve() {
		System.out.println("approve");
		
		
		int[] output = CA.determineLineAmount(lineAmount,prevLineAmount);
		lineAmount = output[0];
		prevLineAmount = output[1];
		
		output = CA.determineLineLength(lineLength,prevLineLength);
		lineLength = output[0];
		prevLineLength = output[1];
		
		
		
		System.out.println("lineAmount: " + lineAmount);
		System.out.println("lineLength: " + lineLength);
		
	}
	
	
	
	
}
